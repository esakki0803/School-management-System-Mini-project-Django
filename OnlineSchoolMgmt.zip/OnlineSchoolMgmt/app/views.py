from django import views
from django.shortcuts import redirect,render
from django.contrib.auth import login,logout,authenticate
from django.http import HttpResponse
from .form import *
from django.views import View
from .models import Attendance

class Home(View):
    def get(self,request):
        notice = Notice.objects.all()
        attendance = Attendance.objects.all()
        marks = Marks.objects.all()
    
        context = {
            'notice':notice,
            'marks':marks,
            'attendance':attendance,
        }
        return render(request,'home.html',context)

class addAttendance(View): 
    def get(self,request):
        if request.user.is_authenticated:
            form=addAttendanceform()
            context={'form':form}
            return render(request,'addAttendance.html',context)
        else: 
            return redirect('home')  
    def post(self,request):       
        form=addAttendanceform(request.POST)
        if(form.is_valid()):
            form.save()
            return redirect('/')
        

class addMarks(View):
    def get(self,request): 
        if request.user.is_authenticated:
            form=addMarksform()       
            context={'form':form}
            return render(request,'addMarks.html',context)
        else: 
            return redirect('home')  
    def post(self,request):
        form=addMarksform(request.POST)
        if(form.is_valid()):
            form.save()
            return redirect('/')

class addNotice(View):
    def get(self,request):    
        if request.user.is_authenticated:
            form=addNoticeform()
            context={'form':form}
            return render(request,'addNotice.html',context)
        else: 
            return redirect('home') 
    def post(self,request):
        form=addNoticeform(request.POST)
        if(form.is_valid()):
            form.save()
            return redirect('/')

class registerPage(View):
    def get(self,request):
        if request.user.is_authenticated:
            return redirect('home') 
        else: 
            form=createuserform()
            context={
                'form':form,
            }
            return render(request,'register.html',context)
    def post(self,request):
        form=createuserform(request.POST)
        if form.is_valid() :
            user=form.save()
            return redirect('login')
        else:
            return redirect('register')
class loginPage(View): 
    def get(self,request):
        if request.user.is_authenticated:
            return redirect('home')
        else:
            context={}
            return render(request,'login.html',context)
    def post(self,request):
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('/')
        else:
            return redirect('login')
class logoutPage(View):
    def get(self,request):
        logout(request)
        return redirect('/')