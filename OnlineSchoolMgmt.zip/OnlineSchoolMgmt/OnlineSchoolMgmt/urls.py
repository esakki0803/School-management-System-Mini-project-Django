from django.contrib import admin
from django.urls import path
from app.views import (Home,addAttendance,addMarks,addNotice,registerPage,loginPage,logoutPage )
 
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',Home.as_view() ,name='home'),
   
    path('addAttendance', addAttendance.as_view() ,name='Attendance'),
    
   
    path('addMarks/', addMarks.as_view(),name='addMarks'),
 
    path('addNotice/', addNotice.as_view(),name='addNotice'),
 
    path('login/', loginPage.as_view(),name='login'),
    path('logout/', logoutPage.as_view(),name='logout'),
    path('register/', registerPage.as_view(),name='register'),
]